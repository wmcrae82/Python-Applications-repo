def main():
    print('WORLD SERIES WINNERS')
    print('Choose a team from the following list to find out how many wins they have.')
    winners = process_file()
    team = user_prompt(winners)
    results = team_selection_wins(team, winners)
    print(f'\nTotal World Series Wins : {results}')


def user_prompt(winners):
    team_set = set(winners)
    team_list = (list(team_set))
    team_list.sort()

    print(team_list[1: 6])
    print(team_list[6: 11])
    print(team_list[11: 16])
    print(team_list[16: 21])
    print(team_list[21: 26])
    print(team_list[26: 28])

    team_selection = input('\nEnter the team name here: ')

    return team_selection


def process_file():
    input_file = open('WorldSeriesWinners.txt', 'r')
    winners = input_file.readlines()
    input_file.close()

    for team in range(len(winners)):
        winners[team] = winners[team].rstrip('\n')

    return winners


def team_selection_wins(team, winners):
    wins = 0
    all_indexes = []
    for i in range(0, len(winners)):
        if winners[i] == team:
            wins += 1
            all_indexes.append(i)

    print(f'{team} won in :')
    for win in all_indexes:
        if win == 0:
            print(f'{int(win) + 1903}, ', end='')
        elif win > 89:
            print(f'{int(win) + 1905}, ', end='')
        else:
            print(f'{int(win) + 1904}, ', end='')

    return wins


if __name__ == '__main__':
    main()
